<?php

$xsl_filename="map.xsl";
$mapfile="regions.xml";
$punktefile="punkte.xml";
include("xslt_process.php");
?>
