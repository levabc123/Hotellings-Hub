SELECT DISTINCT(T1.color),T1.regionname,NULL As P,NULL As F from regions AS T1;
